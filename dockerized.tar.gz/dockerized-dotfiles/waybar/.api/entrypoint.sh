#!/bin/bash
waybar -c /home/user/.config/waybar/config 