#!/bin/bash

# Function to parse package names from a file
parsePackagesFromFile() {
    local file="$1"
    local packages=""

    while IFS= read -r line || [[ -n "$line" ]]; do
        # Skip empty lines and comments
        if [[ -n "$line" && "${line:0:1}" != "#" ]]; then
            if [[ -z "$packages" ]]; then
                packages="$line"
            else
                packages="$packages $line"
            fi
        fi
    done < "$file"

    echo "$packages"
}

# Function to install packages
install_pkgs() {
    local packagesFilePath=$1
    shift
    local overwrite_args="$@"
    local packages=$(parsePackagesFromFile "$packagesFilePath")
    echo "[Installing packages: $packages]"

    # Install packages with the overwrite flag
    sudo pacman --noconfirm -Sy $packages 
}

# Update system packages and install the required packages
sudo pacman -Syu --noconfirm
install_pkgs "$@"
# Clean the package cache again
pacman -Scc --noconfirm