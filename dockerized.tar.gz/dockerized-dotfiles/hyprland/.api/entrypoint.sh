#!/bin/bash

# Check if XDG_RUNTIME_DIR is set
if [ -z "$XDG_RUNTIME_DIR" ]; then
    echo "XDG_RUNTIME_DIR is not set. Please set it before running this script."
    exit 1
fi
# Check if the runtime directory exists and has the correct permissions
if [ -d "$XDG_RUNTIME_DIR" ]; then
    if [ "$(stat -c %a $XDG_RUNTIME_DIR)" -ne 700 ]; then
        echo "Incorrect permissions on $XDG_RUNTIME_DIR. Setting to 700."
        chmod 700 $XDG_RUNTIME_DIR
    fi
else
    echo "$XDG_RUNTIME_DIR does not exist. Creating directory."
    mkdir -p $XDG_RUNTIME_DIR
    chmod 700 $XDG_RUNTIME_DIR
fi
exec Hyprland
